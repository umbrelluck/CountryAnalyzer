from distutils.core import setup

setup(name="CountryAnalyzer",
      version='1.0',
      packages=['packages'],
      package_data={'databases': ['/*.json', '/*.txt']},
      scripts=['main_gui.py']
      )

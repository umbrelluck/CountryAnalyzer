from unittest import TestCase
from country import CountriesADT


class TestCountriesADT(TestCase):
    def setUp(self):
        self.ADT = CountriesADT

    def test_append(self):
        self.fail()

    def test__stable(self):
        self.fail()

    def test_stability(self):
        self.fail()
